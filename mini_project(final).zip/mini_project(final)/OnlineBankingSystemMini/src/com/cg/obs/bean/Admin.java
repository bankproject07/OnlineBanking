package com.cg.obs.bean;

public class Admin {
	private int adminid;
	private String adminPassword;

	public Admin() {
		super();
	}

	public Admin(int adminid, String adminPassword) {
		super();
		this.adminid = adminid;
		this.adminPassword = adminPassword;
	}

	public int getAdminid() {
		return adminid;
	}

	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	@Override
	public String toString() {
		return "Admin [adminid=" + adminid + ", adminPassword=" + adminPassword
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + adminid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Admin other = (Admin) obj;
		if (adminid != other.adminid)
			return false;
		return true;
	}

}
