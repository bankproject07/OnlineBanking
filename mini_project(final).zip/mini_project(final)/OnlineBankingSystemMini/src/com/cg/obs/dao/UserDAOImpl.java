package com.cg.obs.dao;

import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;

public class UserDAOImpl implements IUserDAO {

	@Override
	public Users getUser(int id) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

}
